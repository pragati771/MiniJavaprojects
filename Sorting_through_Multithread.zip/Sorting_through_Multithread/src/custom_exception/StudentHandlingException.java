package custom_exception;

public class StudentHandlingException extends Exception {

	public StudentHandlingException(String message) {
		super(message);
	}

	
}
